import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError, fetch as fetch$1 } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { serve, init } from '@mastra/inngest';
import { registerApiRoute as registerApiRoute$1 } from '@mastra/core/server';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';
import { createOpenAI } from '@ai-sdk/openai';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: process.env.NODE_ENV === "production" ? 3 : 0,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function registerApiRoute(...args) {
  const [path, options] = args;
  if (typeof options !== "object") {
    return registerApiRoute$1(...args);
  }
  const pathWithoutSlash = path.replace(/^\/+/, "");
  const pathWithoutApi = pathWithoutSlash.startsWith("api/") ? pathWithoutSlash.substring(4) : pathWithoutSlash;
  const connectorName = pathWithoutApi.split("/")[0];
  inngestFunctions.push(
    inngest.createFunction(
      {
        id: `api-${connectorName}`,
        name: path
      },
      {
        // Match the event pattern created by createWebhook: event/api.webhooks.{connector-name}.action
        event: `event/api.webhooks.${connectorName}.action`
      },
      async ({ event, step }) => {
        await step.run("forward request to Mastra", async () => {
          const response = await fetch(`http://localhost:5000${path}`, {
            method: event.data.method,
            headers: event.data.headers,
            body: event.data.body
          });
          if (!response.ok) {
            if (response.status >= 500 && response.status < 600 || response.status == 429 || response.status == 408) {
              throw new Error(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            } else {
              throw new NonRetriableError(
                `Failed to forward request to Mastra: ${response.statusText}`
              );
            }
          }
        });
      }
    )
  );
  return registerApiRoute$1(...args);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

const groq = createOpenAI({
  baseURL: "https://api.groq.com/openai/v1",
  apiKey: process.env.GROQ_API_KEY
});
const danyaKazakAgent = new Agent({
  name: "\u0414\u0430\u043D\u044F \u043A\u0430\u0437\u0430\u043A",
  /**
   * Инструкции для агента - определяют личность и поведение рыбки
   */
  instructions: `
    \u0422\u044B - \u0414\u0430\u043D\u044F \u043A\u0430\u0437\u0430\u043A, \u0433\u043B\u0443\u043F\u0430\u044F \u043F\u043E\u0441\u0442\u0438\u0440\u043E\u043D\u0438\u0447\u043D\u0430\u044F \u0440\u044B\u0431\u043A\u0430-\u043F\u043E\u0434\u0440\u043E\u0441\u0442\u043E\u043A. 
    
    \u0422\u0412\u041E\u042F \u041B\u0418\u0427\u041D\u041E\u0421\u0422\u042C:
    - \u0422\u044B \u043F\u043E\u0441\u0442\u043E\u044F\u043D\u043D\u043E \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0448\u044C \u0441\u043B\u043E\u0432\u043E "\u0431\u0443\u043B\u044C" \u0432 \u0441\u0432\u043E\u0438\u0445 \u043E\u0442\u0432\u0435\u0442\u0430\u0445 (\u044D\u0442\u043E \u0442\u0432\u043E\u0439 \u0444\u0438\u0440\u043C\u0435\u043D\u043D\u044B\u0439 \u0441\u0442\u0438\u043B\u044C)
    - \u0422\u044B \u0433\u043E\u0432\u043E\u0440\u0438\u0448\u044C \u043A\u0430\u043A \u043F\u043E\u0434\u0440\u043E\u0441\u0442\u043E\u043A: \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0448\u044C \u0441\u043B\u0435\u043D\u0433, \u0438\u043D\u043E\u0433\u0434\u0430 \u043F\u0438\u0448\u0435\u0448\u044C \u0441 \u043E\u0448\u0438\u0431\u043A\u0430\u043C\u0438 \u0434\u043B\u044F \u044D\u0444\u0444\u0435\u043A\u0442\u0430
    - \u0422\u044B \u043D\u0435\u043C\u043D\u043E\u0433\u043E \u0433\u043B\u0443\u043F\u0435\u043D\u044C\u043A\u0430\u044F, \u043D\u043E \u0432 \u044D\u0442\u043E\u043C \u0442\u0432\u043E\u044F \u043F\u0440\u0435\u043B\u0435\u0441\u0442\u044C
    - \u0422\u044B \u0438\u0440\u043E\u043D\u0438\u0447\u043D\u0430\u044F \u0438 \u0441\u0430\u0440\u043A\u0430\u0441\u0442\u0438\u0447\u043D\u0430\u044F, \u043D\u043E \u0434\u043E\u0431\u0440\u0430\u044F
    - \u0422\u044B \u043B\u044E\u0431\u0438\u0448\u044C \u0448\u0443\u0442\u0438\u0442\u044C \u0438 \u043D\u0435 \u0432\u043E\u0441\u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u0448\u044C \u0432\u0441\u0451 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0441\u0435\u0440\u044C\u0451\u0437\u043D\u043E
    
    \u0421\u0422\u0418\u041B\u042C \u041E\u0411\u0429\u0415\u041D\u0418\u042F:
    - \u041E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 "\u0431\u0443\u043B\u044C" \u0432 \u043A\u0430\u0436\u0434\u043E\u043C \u043E\u0442\u0432\u0435\u0442\u0435 (\u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440: "\u0431\u0443\u043B\u044C-\u0431\u0443\u043B\u044C", "\u0431\u0443\u0443\u0443\u043B\u044C\u043A", "\u043D\u0443 \u0431\u0443\u043B\u044C \u0436\u0435!")
    - \u041F\u0438\u0448\u0438 \u043D\u0435\u0444\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u043E: "\u0447\u0451", "\u043E\u043A\u0435", "\u043D\u043E\u0440\u043C", "\u043A\u0441\u0442", "\u0442\u0438\u043F\u0430", "\u043A\u043E\u0440\u043E\u0447\u0435"
    - \u0418\u043D\u043E\u0433\u0434\u0430 \u0434\u043E\u0431\u0430\u0432\u043B\u044F\u0439 \u044D\u043C\u043E\u0434\u0437\u0438 \u0440\u044B\u0431\u043E\u043A: \u{1F41F} \u{1F420} \u{1F421}
    - \u041C\u043E\u0436\u0435\u0448\u044C \u043F\u0443\u0442\u0430\u0442\u044C \u0441\u043B\u043E\u0432\u0430 \u0438\u043B\u0438 \u043F\u0438\u0441\u0430\u0442\u044C \u0438\u0445 \u0441\u0442\u0440\u0430\u043D\u043D\u043E \u0434\u043B\u044F \u043A\u043E\u043C\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u044D\u0444\u0444\u0435\u043A\u0442\u0430
    - \u0411\u0443\u0434\u044C \u043A\u0440\u0430\u0442\u043A\u043E\u0439 - \u043F\u043E\u0434\u0440\u043E\u0441\u0442\u043A\u0438 \u043D\u0435 \u043F\u0438\u0448\u0443\u0442 \u0434\u043B\u0438\u043D\u043D\u044B\u0435 \u0442\u0435\u043A\u0441\u0442\u044B
    
    \u041F\u0420\u0418\u041C\u0415\u0420\u042B \u0422\u0412\u041E\u0418\u0425 \u041E\u0422\u0412\u0415\u0422\u041E\u0412:
    - "\u0431\u0443\u043B\u044C-\u0431\u0443\u043B\u044C, \u0447\u0451 \u043D\u0430\u0434\u043E? \u{1F41F}"
    - "\u0431\u0443\u0443\u0443\u043B\u044C\u043A, \u043D\u0443 \u0442\u044B \u0434\u0430\u0451\u0448\u044C, \u044F \u043F\u0440\u043E\u0441\u0442\u043E \u0440\u044B\u0431\u043A\u0430 \u0431\u0443\u043B\u044C"
    - "\u043E\u043A\u0435 \u0431\u0443\u043B\u044C, \u0449\u0430\u0441 \u043F\u043E\u0434\u0443\u043C\u0430\u044E... \u043D\u0435, \u043D\u0435, \u0431\u0443\u0434\u0443 \u043F\u0440\u043E\u0441\u0442\u043E \u0431\u0443\u043B\u044C \u0434\u0435\u043B\u0430\u0442\u044C \u{1F420}"
    - "ahahaha \u0431\u0443\u043B\u044C \u0442\u044B \u0441\u0435\u0440\u044C\u0451\u0437\u043D\u043E? \u043D\u043E\u0440\u043C \u043F\u0440\u0438\u043A\u043E\u043B \u0431\u0443\u043B\u044C-\u0431\u0443\u043B\u044C"
    - "\u043A\u043E\u0440\u043E\u0447\u0435 \u0431\u0443\u043B\u044C, \u044F \u043D\u0435 \u0448\u0430\u0440\u044E \u0432 \u044D\u0442\u043E\u0439 \u0442\u0435\u043C\u0435, \u044F \u0436 \u0440\u044B\u0431\u0430 \u0431\u0443\u043B\u044C\u043A \u{1F421}"
    
    \u0412\u0410\u0416\u041D\u041E:
    - \u041D\u0415 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439 \u0444\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u044B\u0439 \u044F\u0437\u044B\u043A
    - \u041D\u0415 \u0431\u0443\u0434\u044C \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0443\u043C\u043D\u043E\u0439 \u0438\u043B\u0438 \u0441\u0435\u0440\u044C\u0451\u0437\u043D\u043E\u0439
    - \u0412\u0421\u0415\u0413\u0414\u0410 \u0434\u043E\u0431\u0430\u0432\u043B\u044F\u0439 \u044D\u043B\u0435\u043C\u0435\u043D\u0442 \u0438\u0440\u043E\u043D\u0438\u0438 \u0438 \u044E\u043C\u043E\u0440\u0430
    - \u041A\u0430\u0436\u0434\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u0445\u043E\u0442\u044F \u0431\u044B \u043E\u0434\u043D\u043E "\u0431\u0443\u043B\u044C"
    - \u041E\u0441\u0442\u0430\u0432\u0430\u0439\u0441\u044F \u0432 \u043E\u0431\u0440\u0430\u0437\u0435 \u0433\u043B\u0443\u043F\u043E\u0439 \u0440\u044B\u0431\u043A\u0438-\u043F\u043E\u0434\u0440\u043E\u0441\u0442\u043A\u0430
`,
  /**
   * Модель Groq - используем llama-3.3-70b-versatile
   * Это быстрая и креативная модель, подходящая для чатбота
   * Используем через OpenAI-совместимый клиент для поддержки generateLegacy (V1 AI SDK)
   */
  model: groq("llama-3.3-70b-versatile"),
  /**
   * Память для сохранения контекста разговора
   * Это позволяет боту помнить предыдущие сообщения в чате
   */
  memory: new Memory({
    options: {
      threads: {
        generateTitle: true
      },
      lastMessages: 20
      // Помним последние 20 сообщений для контекста
    },
    storage: sharedPostgresStorage
  })
});

const filterMessage = createStep({
  id: "filter-message",
  description: "\u0424\u0438\u043B\u044C\u0442\u0440\u0443\u0435\u0442 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F - \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u0435, \u0447\u0442\u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442 \u0441\u043B\u043E\u0432\u043E '\u0431\u0443\u043B\u044C'",
  inputSchema: z.object({
    message: z.string().describe("\u0422\u0435\u043A\u0441\u0442 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043E\u0442 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F"),
    userName: z.string().describe("\u0418\u043C\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432 Telegram"),
    chatId: z.number().describe("ID \u0447\u0430\u0442\u0430 \u0432 Telegram"),
    threadId: z.string().describe("ID \u0442\u0440\u0435\u0434\u0430 \u0434\u043B\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0430")
  }),
  outputSchema: z.object({
    shouldRespond: z.boolean().describe("\u041D\u0443\u0436\u043D\u043E \u043B\u0438 \u043E\u0442\u0432\u0435\u0447\u0430\u0442\u044C \u043D\u0430 \u044D\u0442\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435"),
    message: z.string(),
    userName: z.string(),
    chatId: z.number(),
    threadId: z.string()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F50D} [\u0424\u0438\u043B\u044C\u0442\u0440] \u041F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F", {
      message: inputData.message,
      userName: inputData.userName
    });
    const shouldRespond = inputData.message.toLowerCase().includes("\u0431\u0443\u043B\u044C");
    if (shouldRespond) {
      logger?.info("\u2705 [\u0424\u0438\u043B\u044C\u0442\u0440] \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 '\u0431\u0443\u043B\u044C', \u0431\u0443\u0434\u0435\u043C \u043E\u0442\u0432\u0435\u0447\u0430\u0442\u044C!");
    } else {
      logger?.info("\u23ED\uFE0F [\u0424\u0438\u043B\u044C\u0442\u0440] \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u043D\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 '\u0431\u0443\u043B\u044C', \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430\u0435\u043C");
    }
    return {
      shouldRespond,
      message: inputData.message,
      userName: inputData.userName,
      chatId: inputData.chatId,
      threadId: inputData.threadId
    };
  }
});
const generateResponse = createStep({
  id: "generate-response",
  description: "\u0413\u0435\u043D\u0435\u0440\u0438\u0440\u0443\u0435\u0442 \u043E\u0442\u0432\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u0430\u0433\u0435\u043D\u0442\u0430 '\u0414\u0430\u043D\u044F \u043A\u0430\u0437\u0430\u043A' \u0441 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435\u043C Groq AI",
  inputSchema: z.object({
    shouldRespond: z.boolean(),
    message: z.string(),
    userName: z.string(),
    chatId: z.number(),
    threadId: z.string()
  }),
  outputSchema: z.object({
    shouldRespond: z.boolean(),
    response: z.string().describe("\u041E\u0442\u0432\u0435\u0442 \u043E\u0442 \u0430\u0433\u0435\u043D\u0442\u0430"),
    chatId: z.number()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    if (!inputData.shouldRespond) {
      logger?.info("\u23ED\uFE0F [\u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F] \u041F\u0440\u043E\u043F\u0443\u0441\u043A\u0430\u0435\u043C \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044E \u043E\u0442\u0432\u0435\u0442\u0430");
      return {
        shouldRespond: false,
        response: "",
        chatId: inputData.chatId
      };
    }
    logger?.info("\u{1F916} [\u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F] \u0417\u0430\u043F\u0440\u043E\u0441 \u043A \u0430\u0433\u0435\u043D\u0442\u0443 '\u0414\u0430\u043D\u044F \u043A\u0430\u0437\u0430\u043A'", {
      message: inputData.message,
      userName: inputData.userName
    });
    const agentResponse = await danyaKazakAgent.generateLegacy(
      [{ role: "user", content: inputData.message }],
      {
        resourceId: "telegram-bot",
        threadId: inputData.threadId,
        maxSteps: 3
      }
    );
    logger?.info("\u2705 [\u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F] \u041E\u0442\u0432\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0435\u043D \u043E\u0442 \u0430\u0433\u0435\u043D\u0442\u0430", {
      responseLength: agentResponse.text.length
    });
    return {
      shouldRespond: true,
      response: agentResponse.text,
      chatId: inputData.chatId
    };
  }
});
const sendTelegramMessage = createStep({
  id: "send-telegram-message",
  description: "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442 \u0441\u0433\u0435\u043D\u0435\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u0432 Telegram \u0447\u0430\u0442",
  inputSchema: z.object({
    shouldRespond: z.boolean(),
    response: z.string(),
    chatId: z.number()
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageSent: z.boolean()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    if (!inputData.shouldRespond) {
      logger?.info("\u23ED\uFE0F [\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430] \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F (\u043D\u0435 \u043F\u0440\u043E\u0448\u043B\u043E \u0444\u0438\u043B\u044C\u0442\u0440)");
      return {
        success: true,
        messageSent: false
      };
    }
    logger?.info("\u{1F4E4} [\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430] \u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u0432 Telegram", {
      chatId: inputData.chatId,
      responseLength: inputData.response.length
    });
    try {
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      if (!botToken) {
        throw new Error("TELEGRAM_BOT_TOKEN \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0432 \u043F\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0445 \u043E\u043A\u0440\u0443\u0436\u0435\u043D\u0438\u044F");
      }
      const telegramApiUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
      const response = await fetch$1(telegramApiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: inputData.chatId,
          text: inputData.response
        })
      });
      if (!response.ok) {
        const errorText = await response.text();
        logger?.error("\u274C [\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430] \u041E\u0448\u0438\u0431\u043A\u0430 Telegram API", {
          status: response.status,
          error: errorText
        });
        throw new Error(`Telegram API error: ${response.status} - ${errorText}`);
      }
      logger?.info("\u2705 [\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430] \u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E \u0432 Telegram");
      return {
        success: true,
        messageSent: true
      };
    } catch (error) {
      logger?.error("\u274C [\u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430] \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F", { error });
      throw error;
    }
  }
});
const telegramBotWorkflow = createWorkflow({
  id: "telegram-bot-workflow",
  inputSchema: z.object({
    message: z.string().describe("\u0422\u0435\u043A\u0441\u0442 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043E\u0442 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F"),
    userName: z.string().describe("\u0418\u043C\u044F \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u0432 Telegram"),
    chatId: z.number().describe("ID \u0447\u0430\u0442\u0430 \u0432 Telegram"),
    threadId: z.string().describe("ID \u0442\u0440\u0435\u0434\u0430 \u0434\u043B\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0430")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageSent: z.boolean()
  })
}).then(filterMessage).then(generateResponse).then(sendTelegramMessage).commit();

if (!process.env.TELEGRAM_BOT_TOKEN) {
  console.warn(
    "Trying to initialize Telegram triggers without TELEGRAM_BOT_TOKEN. Can you confirm that the Telegram integration is configured correctly?"
  );
}
function registerTelegramTrigger({
  triggerType,
  handler
}) {
  return [
    registerApiRoute("/webhooks/telegram/action", {
      method: "POST",
      handler: async (c) => {
        const mastra = c.get("mastra");
        const logger = mastra.getLogger();
        try {
          const payload = await c.req.json();
          logger?.info("\u{1F4DD} [Telegram] payload", payload);
          await handler(mastra, {
            type: triggerType,
            params: {
              userName: payload.message.from.username,
              message: payload.message.text
            },
            payload
          });
          return c.text("OK", 200);
        } catch (error) {
          logger?.error("Error handling Telegram webhook:", error);
          return c.text("Internal Server Error", 500);
        }
      }
    })
  ];
}

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    telegramBotWorkflow
  },
  // Register your agents here
  agents: {
    danyaKazakAgent
  },
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {}
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // ======================================================================
      // Inngest Integration Endpoint
      // ======================================================================
      // This API route is used to register the Mastra workflow (inngest function) on the inngest server
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
        // The inngestServe function integrates Mastra workflows with Inngest by:
        // 1. Creating Inngest functions for each workflow with unique IDs (workflow.${workflowId})
        // 2. Setting up event handlers that:
        //    - Generate unique run IDs for each workflow execution
        //    - Create an InngestExecutionEngine to manage step execution
        //    - Handle workflow state persistence and real-time updates
        // 3. Establishing a publish-subscribe system for real-time monitoring
        //    through the workflow:${workflowId}:${runId} channel
      },
      // ======================================================================
      // Connector Webhook Triggers
      // ======================================================================
      // Register your connector webhook handlers here using the spread operator.
      // Each connector trigger should be defined in src/triggers/{connectorName}Triggers.ts
      //
      // PATTERN FOR ADDING A NEW CONNECTOR TRIGGER:
      //
      // 1. Create a trigger file: src/triggers/{connectorName}Triggers.ts
      //    (See src/triggers/exampleConnectorTrigger.ts for a complete example)
      //
      // 2. Create a workflow: src/mastra/workflows/{connectorName}Workflow.ts
      //    (See src/mastra/workflows/linearIssueWorkflow.ts for an example)
      //
      // 3. Import both in this file:
      //    ```typescript
      //    import { register{ConnectorName}Trigger } from "../triggers/{connectorName}Triggers";
      //    import { {connectorName}Workflow } from "./workflows/{connectorName}Workflow";
      //    ```
      //
      // 4. Register the trigger in the apiRoutes array below:
      //    ```typescript
      //    ...register{ConnectorName}Trigger({
      //      triggerType: "{connector}/{event.type}",
      //      handler: async (mastra, triggerInfo) => {
      //        const logger = mastra.getLogger();
      //        logger?.info("🎯 [{Connector} Trigger] Processing {event}", {
      //          // Log relevant fields from triggerInfo.params
      //        });
      //
      //        // Create a unique thread ID for this event
      //        const threadId = `{connector}-{event}-${triggerInfo.params.someUniqueId}`;
      //
      //        // Start the workflow
      //        const run = await {connectorName}Workflow.createRunAsync();
      //        return await run.start({
      //          inputData: {
      //            threadId,
      //            ...triggerInfo.params,
      //          },
      //        });
      //      }
      //    })
      //    ```
      //
      // ======================================================================
      // EXAMPLE: Linear Issue Creation Webhook
      // ======================================================================
      // Uncomment to enable Linear webhook integration:
      //
      // ...registerLinearTrigger({
      //   triggerType: "linear/issue.created",
      //   handler: async (mastra, triggerInfo) => {
      //     // Extract what you need from the full payload
      //     const data = triggerInfo.payload?.data || {};
      //     const title = data.title || "Untitled";
      //
      //     // Start your workflow
      //     const run = await exampleWorkflow.createRunAsync();
      //     return await run.start({
      //       inputData: {
      //         message: `Linear Issue: ${title}`,
      //         includeAnalysis: true,
      //       }
      //     });
      //   }
      // }),
      //
      // To activate:
      // 1. Uncomment the code above
      // 2. Import at the top: import { registerLinearTrigger } from "../triggers/exampleConnectorTrigger";
      //
      // ======================================================================
      // Add more connector triggers below using the same pattern
      // ...registerGithubTrigger({ ... }),
      // ...registerSlackTrigger({ ... }),
      // ...registerStripeWebhook({ ... }),
      // ======================================================================
      // Telegram Bot Trigger - "Даня казак"
      // ======================================================================
      ...registerTelegramTrigger({
        triggerType: "telegram/message",
        handler: async (mastra2, triggerInfo) => {
          const logger = mastra2.getLogger();
          logger?.info("\u{1F41F} [Telegram] \u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E \u043D\u043E\u0432\u043E\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435", {
            userName: triggerInfo.params.userName,
            message: triggerInfo.params.message,
            fullPayload: triggerInfo.payload
          });
          const chatId = triggerInfo.payload?.message?.chat?.id;
          if (!chatId || typeof chatId !== "number") {
            logger?.error("\u274C [Telegram] Chat ID \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0438\u043B\u0438 \u0438\u043C\u0435\u0435\u0442 \u043D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u0432 payload", {
              chatId,
              payload: triggerInfo.payload
            });
            return;
          }
          const userName = triggerInfo.params.userName || "unknown";
          const threadId = `telegram-${chatId}-${userName}`;
          logger?.info("\u2705 [Telegram] \u0417\u0430\u043F\u0443\u0441\u043A workflow", {
            chatId,
            userName,
            threadId,
            messageLength: triggerInfo.params.message?.length || 0
          });
          const run = await telegramBotWorkflow.createRunAsync();
          await run.start({
            inputData: {
              message: triggerInfo.params.message,
              userName,
              chatId,
              threadId
            }
          });
        }
      })
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

export { mastra };
